package net.sf.jxls.tag;

/**
 * @author Leonid Vysochyn
* @version 1.0
*          Created: 22.01.2008
*/
public class LoopStatus {
    /** The index of the current item in the underlying collection */
    int index;

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }
}
